package no.uib.inf112.enums;

public enum StaticObjectType {

    //Walls
    WOODEN_WALL,
    LONG_WOODEN_WALL,

    //Furniture
    DARK_TABLE_ROUNDED,
    DARK_TABLE_SQUARE,
    DARK_TABLE_SMALL,
    BEIGE_COUCH_DOWN,
    BEIGE_COUCH_SMALL,
    BEIGE_CHAIR_WOOD_UP,
    BEIGE_CHAIR_WOOD_DOWN,
    RED_CHAIR_LEFT,
    RED_CHAIR_RIGHT,
    BEIGE_BIG_BED,
    BEIGE_SMALL_BED,
    DARK_DRAWER_SMALL,
    DARK_DRAWER_SMALL_UP,
    DARK_DRAWER_LONG,
    PLANT_ONE,
    PLANT_TWO,
    GREY_TV,

    //water
    WATER
}
