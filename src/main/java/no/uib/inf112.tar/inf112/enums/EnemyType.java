package no.uib.inf112.enums;

public enum EnemyType {
    ZOMBIE,
    GHOUL,
}
