package no.uib.inf112.enums;

public enum PuddleType {
    ACID
}
