package no.uib.inf112.interfaces;

import no.uib.inf112.enums.BuffType;
import no.uib.inf112.enums.CollectableType;
import no.uib.inf112.enums.GunType;

public interface IGun {
    
    /**
     * @return max ammunition of gun
     */
    public int maxAmmunition();

    /**
     * @return current ammunition of gun
     */
    public int currentAmmunition();

    /**
     * @return type of this gun
     */
    public GunType type();

    /**
     * @return fire rate of gun - lower number is faster
     */
    public int fireRate();

    /**
     * The angle of the accuracy-cone of th gun
     * @return angle of cone - lower is more accurate
     */
    public double accuracy();

    void increaseAmmo(int byAmount);

    CollectableType getAmmoType();

    /**
     * @return how far this gun shoots
     */
    public int range();

    /**
     * @return the ammount of damage this gun deals
     */
    public int damage(BuffType type);

    /**
     * Reduces ammunition by 1
     * returns True if out of ammunition
     */
    public boolean shoot(BuffType type);

    /**
     * Prepares for a new shot
     */
    public void reload();
}
