package no.uib.inf112.player;

import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;

import com.badlogic.gdx.Game;
import no.uib.inf112.config.Config;
import no.uib.inf112.controller.DirectionHandler;
import no.uib.inf112.enums.*;
import no.uib.inf112.interfaces.*;
import no.uib.inf112.map.items.Collectable;
import no.uib.inf112.player.guns.DEagle;
import no.uib.inf112.player.guns.MP5;
import no.uib.inf112.player.guns.ShotGun;
import no.uib.inf112.player.guns.gunshots.PistolShot;
import no.uib.inf112.records.ShotDestination;
import no.uib.inf112.utility.SoundHandler;

public class Player implements IControllablePlayer, IViewablePlayer {
    private int playerSpeed = Config.getInt("playerMoveSpeed");
    private static final int ANIMATION_COUNT = 20;
    private static final int MAX_HP = 100;
    private int currentHP;

    private final DirectionHandler dirHandler;

    private Rectangle2D.Double hitbox;
    private Rectangle2D.Double bounds;
    private Direction currentDirection;
    private double aimAngle;
    private int animationIndex;
    private IMap map;
    private int armor = 0;

    private IGun currentGun;
    private HashMap<GunType, IGun> guns;

    private BuffType buffType;
    private int buffCounter;

    private Inventory inventory;



    public Player(Rectangle2D.Double hitbox, Rectangle2D.Double bounds, IMap map) {
        this.hitbox = hitbox;
        this.bounds = bounds;
        this.dirHandler = new DirectionHandler();
        this.animationIndex = 0;
        this.map = map;
        this.aimAngle = 0;
        setDirection(Direction.WEST);

        // GUNS
        this.currentGun = new DEagle();
        this.guns = new HashMap<>();
        this.guns.put(this.currentGun.type(), this.currentGun);
        this.guns.put(GunType.MP5, new MP5());
        this.guns.put(GunType.SHOTGUN, new ShotGun());

        this.currentHP = MAX_HP;

        // buffs
        this.buffType = BuffType.NONE;
        this.buffCounter = 0;
        this.inventory = new Inventory(this, map);
    }

    @Override
    public void setPlayerSpeed(int amount){
        this.playerSpeed = amount;
    }

    /**
     * Check how many of a given item is in the inventory
     * @param item
     * @return an int of how many of this item the player holds.
     */
    @Override
    public int getAmountInInventory(CollectableType item){
        return inventory.getAmountInInventory(item);
    }

    /**
     * Adds a collectable to the player's inventory.
     * @param item
     */
    public void addToInventory(CollectableType item){
        inventory.addToInventory(item);
    }

    @Override
    public void openCloseInventory(){
        inventory.toggleVisible();
    }

    @Override
    public Inventory getInventory(){
        return inventory;
    }

    public void pressMove(Direction dir) {
        this.dirHandler.add(dir);
    }

    public void releaseMove(Direction dir) {
        this.dirHandler.remove(dir);
    }

    public boolean isMoving() {
        return dirHandler.isMoving();
    }


    public void updateMovement() {
        Direction dir = dirHandler.getDirection();
        if (dir != null) {
            movePlayer(dir);
            setDirection(dir);
        }
    }

    private void checkWinningCondition(){
        if(map.getHelicopter().isFuelFull() && map.getGameState() == GameState.ACTIVE_GAME){
            //got enough fuel
            if(inventory.getAmountInInventory(CollectableType.CHOPPERKEY) != 0){
                map.setGameState(GameState.VICTORY);
                //yey
            }
        }

        //if we need more fuels
        while(!map.getHelicopter().isFuelFull() && inventory.getAmountInInventory(CollectableType.GASCAN) > 0){
            inventory.useItemFromInventory(CollectableType.GASCAN);
            map.getHelicopter().depositGas();
        }
    }


    public void aimAtWorldPosition(double worldX, double worldY) {
        double playerCenterX = this.hitbox.getCenterX();
        double playerCenterY = this.hitbox.getCenterY();
        double deltaX = worldX - playerCenterX;
        double deltaY = worldY - playerCenterY;
        this.aimAngle = Math.atan2(deltaY, deltaX);
    }

    @Override
    public Rectangle2D.Double getHitbox() {
        return this.hitbox;
    }

    @Override
    public void movePlayer(Direction dir) {
        if (map.getGameState() != GameState.ACTIVE_GAME){
            return;
        }

        Rectangle2D.Double proposedMove = possibleMove(dir);
        if (legalMove(proposedMove)) {
            this.hitbox = proposedMove;
        } else {
            trySlide(dir);
        }
        tryPickupItem();
    }

    private void tryPickupItem(){
        for(ICollectable item : map.getActiveItems()){
            if(item.getHitbox().intersects(this.hitbox)){
               item.pickUp();
            }
        }
    }

    private void trySlide(Direction dir) {
        switch (dir) {
            case SOUTH_EAST -> {
                Rectangle2D.Double east = possibleMove(Direction.EAST);
                if (legalMove(east)) {
                    this.hitbox = east;
                }
                Rectangle2D.Double south = possibleMove(Direction.SOUTH);
                if (legalMove(south)) {
                    this.hitbox = south;
                }
                break;
            }
            case SOUTH_WEST -> {
                Rectangle2D.Double west = possibleMove(Direction.WEST);

                if (legalMove(west)) {
                    this.hitbox = west;
                }
                Rectangle2D.Double south = possibleMove(Direction.SOUTH);
                if (legalMove(south)) {
                    this.hitbox = south;
                }
                break;
            }
            case NORTH_WEST -> {
                Rectangle2D.Double north = possibleMove(Direction.NORTH);

                if (legalMove(north)) {
                    this.hitbox = north;
                }
                Rectangle2D.Double west = possibleMove(Direction.WEST);
                if (legalMove(west)) {
                    this.hitbox = west;
                }
                break;
            }
            case NORTH_EAST -> {
                Rectangle2D.Double north = possibleMove(Direction.NORTH);

                if (legalMove(north)) {
                    this.hitbox = north;
                }
                Rectangle2D.Double east = possibleMove(Direction.EAST);
                if (legalMove(east)) {
                    this.hitbox = east;
                }
                break;
            }
            default -> {
                /* No legal move - do nothing */}
        }
    }

    /**
     * Checks that the player can move in a proposed direction.
     * 
     * @param dir proposed movement direction.
     * @return true if move is within map, false if else.
     */
    private boolean legalMove(Rectangle2D.Double proposedMove) {

        // checks for map border
        if (proposedMove.getX() + proposedMove.getWidth() > bounds.getMaxX() ||
                proposedMove.getY() + proposedMove.getHeight() > bounds.getMaxY() ||
                proposedMove.getX() < bounds.getMinX() ||
                proposedMove.getY() < bounds.getMinY()) {
            return false;
        }

        for (IEnemy enemy : this.map.getEnemies()) {
            if (!enemy.isAlive()){
                continue; //we can walk over dead enemies
            }

            if (proposedMove.intersects(enemy.getHitbox())) {
                return false;
            }
        }

        // Check for wall collisions
        for (IStaticObject o : this.map.getStaticObjects()) {
            if (proposedMove.intersects(o.getBounds())) {
                return false;
            }
        }

        //Check vehicle collision
        for (IVehicle vehicle : this.map.getVehicles()){
            if (proposedMove.intersects(vehicle.getBounds())){
                checkWinningCondition();
                return false;
            }
        }

        return true;
    }

    /**
     * Gives a new player position based on proposed direction.
     * 
     * @param dir proposed movement direction.
     * @return a new position for player
     */
    private Rectangle2D.Double possibleMove(Direction dir) {
        int deltaX = 0;
        int deltaY = 0;

        switch (dir) {
            case NORTH:
                deltaY = -playerSpeed;
                break;
            case SOUTH:
                deltaY = playerSpeed;
                break;
            case EAST:
                deltaX = playerSpeed;
                break;
            case WEST:
                deltaX = -playerSpeed;
                break;
            case NORTH_EAST: {
                deltaX = playerSpeed;
                deltaY = -playerSpeed;
                break;
            }
            case NORTH_WEST: {
                deltaX = -playerSpeed;
                deltaY = -playerSpeed;
                break;
            }
            case SOUTH_EAST: {
                deltaX = playerSpeed;
                deltaY = playerSpeed;
                break;
            }
            case SOUTH_WEST: {
                deltaX = -playerSpeed;
                deltaY = playerSpeed;
                break;
            }

            default:
                break;
        }
        return new Rectangle2D.Double(
                this.hitbox.getX() + deltaX,
                this.hitbox.getY() + deltaY,
                hitbox.getWidth(),
                hitbox.getHeight());
    }

    @Override
    public Direction getDirection() {
        return this.currentDirection;
    }

    @Override
    public void setDirection(Direction dir) {
        this.currentDirection = dir;
    }

    @Override
    public int getAnimationIndex() {
        return this.animationIndex;
    }

    @Override
    public double getFacingAngle() {
        return this.aimAngle;
    }

    @Override
    public void setFacingAngle(double angle) {
        this.aimAngle = angle;
    }

    @Override
    public void incrementAnimationIndex() {
        this.animationIndex = (this.animationIndex + 1) % ANIMATION_COUNT;
    }

    @Override
    public GunType gunType() {
        return this.currentGun.type();
    }

    @Override
    public void setGunType(GunType gun) {

        if (this.guns.containsKey(gun)) {
            this.currentGun = this.guns.get(gun);
        }
    }

    public HashMap<GunType, IGun> getOwnedGuns(){
        return this.guns;
    }

    @Override
    public int currentAmmunition() {
        return this.currentGun.currentAmmunition();
    }

    @Override
    public int maxAmmunition() {
        return this.currentGun.maxAmmunition();
    }

    @Override
    public int getMaxHP() {
        return MAX_HP;
    }

    @Override
    public int getCurrentHP() {
        return this.currentHP;
    }

    @Override
    public void healHP(int heal) {
        int newHP = this.currentHP + heal;
        if (newHP > this.getMaxHP()) {
            this.currentHP = MAX_HP;
        } else {
            this.currentHP = newHP;
        }
    }

    @Override
    public void takeDamage(int damage) {
        if (this.map.getGameState() != GameState.ACTIVE_GAME){
            return;
        }
        int newHP = (armor > 0) ? this.currentHP - damage/2 : this.currentHP - damage; //half damage if armor is active

        boolean overHalf = this.currentHP >= 50;
        boolean notDead = this.currentHP > 0;
        if (newHP < 0) {
            this.currentHP = 0;
        } else {
            this.currentHP = newHP;
        }
        if (notDead && this.currentHP == 0){
            this.map.getSoundHandler().playPlayerDamageSound(1);
        }else if (overHalf && this.currentHP < 50){
            this.map.getSoundHandler().playPlayerDamageSound(0);
        }
        if (this.currentHP == 0 && this.map.getGameState() != GameState.GAME_OVER){
            this.map.setGameState(GameState.GAME_OVER);
        }
        if(armor > 0){
            armor--;
        }
    }

    @Override
    public int fireRate() {
        return this.currentGun.fireRate();
    }

    @Override
    public boolean shoot(MouseEvent e) {

        if (this.currentGun.shoot(this.buffType)) {
            return false;
        }

        double x1 = this.hitbox.getCenterX();
        double y1 = this.hitbox.getCenterY();

        double baseAngle = this.aimAngle;

        double inaccuracy = this.currentGun.accuracy();
        double range = this.currentGun.range();
        double spread = (Math.random() * 2 - 1) * inaccuracy;

        ShotDestination hit = raycastShot(x1, y1, baseAngle + spread, range);

        IGunShot shot;
        switch (this.currentGun.type()) {

            case DEAGLE -> {
                shot = new PistolShot(x1, y1, hit.x(), hit.y(), this.map);
                this.map.addShot(shot);
                if(buffType == BuffType.DAMAGE){
                map.getCamera().startShake(8,8);
            }}

            case MP5 -> {
                shot = new PistolShot(x1, y1, hit.x(), hit.y(), this.map);
                this.map.addShot(shot);
                if(buffType == BuffType.DAMAGE){
                map.getCamera().startShake(4,6);
            }}

            case SHOTGUN -> {
                for (int i = 0; i < 10; i++) {
                    this.map.addShot(new PistolShot(x1, y1, hit.x(), hit.y(), this.map));
                    spread = (Math.random() * 2 - 1) * inaccuracy;
                    hit = raycastShot(x1, y1, baseAngle + spread, range);
                    if (hit.enemy() != null) {
                        hit.enemy().takeDamage(this.currentGun.damage(this.buffType));
                    }
                }
                if(buffType == BuffType.DAMAGE){
                map.getCamera().startShake(12,15);}
                return true;
            }

            default -> {
                shot = new PistolShot(x1, y1, hit.x(), hit.y(), this.map);
                this.map.addShot(shot); //Should not happen
            }
        }

        if (hit.enemy() != null) {
            hit.enemy().takeDamage(this.currentGun.damage(this.buffType));
        }
        return true;
    }

    // Gippity helped with the math and calculations for the raycast functions - the
    // core idea was my own
    public ShotDestination raycastShot(double startX, double startY, double angle, double range) {
        double endX = startX + Math.cos(angle) * range;
        double endY = startY + Math.sin(angle) * range;
        Line2D.Double line = new Line2D.Double(startX, startY, endX, endY);

        Point2D.Double closestHit = new Point2D.Double(endX, endY);
        double closestDistSq = closestHit.distanceSq(startX, startY);
        IEnemy hitEnemy = null;

        // Check walls
        for (IStaticObject obj : this.map.getStaticObjects()) {
            if (!obj.isWall() || !line.intersects(obj.getBounds())) {
                continue; // Shoots over furniture, skip if not intersecting with object
            }
            Point2D.Double hit = firstIntersection(line, obj.getBounds());
            if (hit != null) {
                double distSq = hit.distanceSq(startX, startY);
                if (distSq < closestDistSq) {
                    closestDistSq = distSq;
                    closestHit = hit;
                    hitEnemy = null;
                }
            }
        }

        // Check enemies
        for (IEnemy enemy : this.map.getEnemies()) {
            if (!line.intersects(enemy.getHitbox()) || !enemy.isAlive()) {
                continue; // Skip if not intersecting enemy or enemy is dead
            }

            Point2D.Double hit = firstIntersection(line, enemy.getHitbox());
            if (hit != null) {
                double distSq = hit.distanceSq(startX, startY);
                if (distSq < closestDistSq) {
                    closestDistSq = distSq;
                    closestHit = hit;
                    hitEnemy = enemy;
                }
            }
        }

        return new ShotDestination(closestHit.x, closestHit.y, hitEnemy);
    }

    private Point2D.Double lineIntersection(Line2D.Double a, Line2D.Double b) {
        double x1 = a.x1;
        double y1 = a.y1;
        double x2 = a.x2;
        double y2 = a.y2;
        double x3 = b.x1;
        double y3 = b.y1;
        double x4 = b.x2;
        double y4 = b.y2;

        double denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);

        if (Math.abs(denom) < 0.000001) {
            return null;
        }

        double t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;
        double u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / denom;

        if (t < 0 || t > 1 || u < 0 || u > 1) {
            return null;
        }

        double px = x1 + t * (x2 - x1);
        double py = y1 + t * (y2 - y1);

        return new Point2D.Double(px, py);
    }

    private Point2D.Double firstIntersection(Line2D.Double ray, Rectangle2D rect) {
        Line2D.Double top = new Line2D.Double(rect.getMinX(), rect.getMinY(), rect.getMaxX(), rect.getMinY());
        Line2D.Double bottom = new Line2D.Double(rect.getMinX(), rect.getMaxY(), rect.getMaxX(), rect.getMaxY());
        Line2D.Double left = new Line2D.Double(rect.getMinX(), rect.getMinY(), rect.getMinX(), rect.getMaxY());
        Line2D.Double right = new Line2D.Double(rect.getMaxX(), rect.getMinY(), rect.getMaxX(), rect.getMaxY());

        Point2D.Double closest = null;
        double bestDistSq = Double.POSITIVE_INFINITY;

        Point2D.Double[] hits = {
                lineIntersection(ray, top),
                lineIntersection(ray, bottom),
                lineIntersection(ray, left),
                lineIntersection(ray, right)
        };

        double sx = ray.x1;
        double sy = ray.y1;

        for (Point2D.Double hit : hits) {
            if (hit != null) {
                double distSq = hit.distanceSq(sx, sy);
                if (distSq < bestDistSq) {
                    bestDistSq = distSq;
                    closest = hit;
                }
            }
        }

        return closest;
    }

    @Override
    public BuffType buffType() {
        return this.buffType;
    }


    public void setBuffCounter(Collectable buff){
        this.buffCounter = buff.getAmount();
        this.buffType = buff.getBuffType();
    }

    public void increaseArmor(int amount){
        this.armor += amount;
    }

    @Override
    public int getArmor(){
        return this.armor;
    }

    @Override
    public int buffCountDown() {
        return this.buffCounter;
    }

    @Override
    public void decrementBuff(SoundHandler handler) {
        if (this.buffCounter <= 0) {
            return;
        }

        this.buffCounter--;
        if (this.buffCounter <= 0) {
            this.buffType = BuffType.NONE;
            this.playerSpeed = Config.getInt("playerMoveSpeed");
            handler.resumeMusic();
        }
    }


    @Override
    public void reload() {
        this.currentGun.reload();
    }

    @Override
    public boolean isAlive() {
        return this.currentHP > 0;
    }
}
